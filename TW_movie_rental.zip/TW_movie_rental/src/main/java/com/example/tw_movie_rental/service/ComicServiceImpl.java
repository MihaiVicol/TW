package com.example.tw_movie_rental.service;

import com.example.tw_movie_rental.Model.Author;
import com.example.tw_movie_rental.Model.Comic;
import com.example.tw_movie_rental.Model.Movie;
import com.example.tw_movie_rental.Model.Publisher;
import com.example.tw_movie_rental.repository.ComicRepository;
import com.example.tw_movie_rental.response.ComicResponse;
import com.example.tw_movie_rental.response.MovieResponse;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

@Service
public class ComicServiceImpl implements ComicService {
    final
    private ComicRepository comicRepository;

    public ComicServiceImpl(ComicRepository comicRepository) {
        this.comicRepository = comicRepository;
    }

    @Override
    public ResponseEntity<ComicResponse> getComics() {
        Collection<Comic> comicList = new ArrayList<>();
        for(int i=0;i<comicRepository.findAll().size();i++)
            comicList.add(comicRepository.findAll().get(i));
        return new ResponseEntity<ComicResponse>(new ComicResponse(comicList), HttpStatus.OK);
    }
}
