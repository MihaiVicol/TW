package com.example.tw_movie_rental.Controller;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
public class OrdersController {
        /*JsonObject convertedObject = new Gson().fromJson(updateData, JsonObject.class);
            List<Interviewer> contacts;
            Type listType = new TypeToken<List<Interviewer>>() {
            }.getType();
            contacts = new Gson().fromJson(convertedObject.getAsJsonArray("interviewers"), listType);
            System.out.println(contacts.get(0).getStatus());
            */
}
