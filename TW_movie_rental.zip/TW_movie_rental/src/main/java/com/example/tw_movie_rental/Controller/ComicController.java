package com.example.tw_movie_rental.Controller;

import com.example.tw_movie_rental.repository.MovieRepository;
import com.example.tw_movie_rental.response.ComicResponse;
import com.example.tw_movie_rental.service.ComicService;
import com.example.tw_movie_rental.service.ComicServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin(origins= {"*"}, maxAge = 48000, allowCredentials = "false")
@RestController
public class ComicController {
    final
    ComicService comicService;
    public ComicController(ComicService comicService) {
        this.comicService = comicService;
    }
    @GetMapping(value = "/comics")
    public ResponseEntity<ComicResponse> getAllComics()
    {
        return comicService.getComics();
    }
}
