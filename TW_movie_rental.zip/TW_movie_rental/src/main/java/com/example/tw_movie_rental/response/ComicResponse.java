package com.example.tw_movie_rental.response;

import com.example.tw_movie_rental.Model.Comic;
import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.Collection;

public class ComicResponse {
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private Collection<Comic> comics;

    public ComicResponse(Collection<Comic> comics) {
        this.comics = comics;
    }

    public Collection<Comic> getComics() {
        return comics;
    }

    public void setComics(Collection<Comic> comics) {
        this.comics = comics;
    }
}
