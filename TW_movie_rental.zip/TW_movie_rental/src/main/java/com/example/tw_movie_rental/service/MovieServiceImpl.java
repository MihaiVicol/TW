package com.example.tw_movie_rental.service;

import com.example.tw_movie_rental.Model.Movie;
import com.example.tw_movie_rental.repository.MovieRepository;
import com.example.tw_movie_rental.response.MovieResponse;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collection;

@Service
public class MovieServiceImpl implements MovieService{
   final
    private MovieRepository movieRepository;

    public MovieServiceImpl(MovieRepository movieRepository) {
        this.movieRepository = movieRepository;
    }

    @Override
    public ResponseEntity<MovieResponse> getMovies() {
        Collection<Movie> movieList = new ArrayList<>();
        for(int i=0;i<movieRepository.findAll().size();i++)
            movieList.add(movieRepository.findAll().get(i));
        return new ResponseEntity<MovieResponse>(new MovieResponse(movieList), HttpStatus.OK);

    }
}
