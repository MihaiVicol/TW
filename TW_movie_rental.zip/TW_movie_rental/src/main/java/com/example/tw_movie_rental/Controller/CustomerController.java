package com.example.tw_movie_rental.Controller;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class CustomerController {
}
