package com.example.tw_movie_rental.response;
import com.example.tw_movie_rental.Model.Movie;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.Collection;

public class MovieResponse {
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private Collection<Movie> movies;

    public MovieResponse(Collection<Movie> movies) {
        this.movies = movies;
    }

    public Collection<Movie> getMovies() {
        return movies;
    }

    public void setMovies(Collection<Movie> movies) {
        this.movies = movies;
    }
}
