package com.example.tw_movie_rental.repository;

import com.example.tw_movie_rental.Model.Publisher;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PublisherRepository extends JpaRepository<Publisher, Object> {
}
